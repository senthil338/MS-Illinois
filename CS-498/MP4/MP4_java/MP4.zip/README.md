# MP2_java_templates
template folder for java version for MP2 (SP2018)
